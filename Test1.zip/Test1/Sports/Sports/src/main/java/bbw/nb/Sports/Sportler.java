/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bbw.nb.Sports;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author nando
 */
public class Sportler {
    private String name;
    private String vorname;
    
    private ArrayList<Sportler> sportler;
    public Sportler(){
        super();
    }
    public Sportler(String name, String vorname){
        super();
        this.name =name;
        this.vorname = vorname;
    }
    
    //Name
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name =name;
    }
    
    //Vorname
    public String getVorname(){
        return vorname;
    }
    public void setVorname(String vorname){
        this.vorname = vorname;
    }
    //add Attribute
    public ArrayList<Sportler> addAttribute(String a, Sportler b){
        
        return sportler;
    }
}
