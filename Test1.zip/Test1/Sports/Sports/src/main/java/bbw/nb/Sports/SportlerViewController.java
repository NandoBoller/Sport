/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bbw.nb.Sports;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 * @author nando
 */
public class SportlerViewController {
    
    @Autowired
    private SportlerListe sportlerList;
    
    @GetMapping("/list-sportler")
    public String listSportler(Sportler model){
    model.addAttribute("listOfSportler", sportlerList.getAllSportler());
    model.addAttribute("newsportler", new Sportler());
    return "sportlerlist";
    }
    
    @PostMapping("/add-sportler")
    public String addSportler(Sportler newsportler, Sportler model){
        sportlerList.addSportler(newsportler);
        model.addAttribute("listOfSportler", sportlerList.getAllSportler());
        return "redirect:/list-sportler";
    }
    
    @PostMapping("/delete-lastsportler")
    public String deleteLastSportler(Sportler model){
        if((sportlerList.getAllSportler()) != null && (sportlerList.getAllSportler().size() > 0)){
            sportlerList.getAllSportler().remove(sportlerList.getAllSportler().size()-1);
        }
        model.addAttribute("listOfSportler", sportlerList.getAllSportler());
        return "redirect:/list-sportler";
    }
    
}
