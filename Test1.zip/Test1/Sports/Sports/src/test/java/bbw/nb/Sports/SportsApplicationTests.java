package bbw.nb.Sports;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportsApplicationTests {

	@Test
	void contextLoads() {
	}

}
